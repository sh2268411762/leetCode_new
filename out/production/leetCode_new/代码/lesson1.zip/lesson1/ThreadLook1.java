package lesson1;

public class ThreadLook1 {

    public static void main(String[] args) {
        while (true){

        }
    }
}
